from flask import request
from flask import Flask, render_template


app = Flask(__name__)


@app.route('/')
def my_form():
    return render_template('index.html')


@app.route('/', methods=['POST'])
def my_form_post():
    text = request.form['text']

    from transformers import AutoModelForSequenceClassification
    from transformers import TFAutoModelForSequenceClassification
    from transformers import AutoTokenizer, AutoConfig
    import numpy as np
    from scipy.special import softmax

    MODEL = f"cardiffnlp/twitter-roberta-base-sentiment-latest"
    tokenizer = AutoTokenizer.from_pretrained(MODEL)
    config = AutoConfig.from_pretrained(MODEL)

    model = AutoModelForSequenceClassification.from_pretrained(MODEL)

    testTxt1 = "Not satisfied. First, there were not enough seats in the venue and students need to get chairs themselves. Second, Audio is inaudible and there were not enough speakers to cover the whole venue. Lastly, The presentation is not visible from the back and ventilation is not enough."

    def stringSentement(text):
        resultScore = []
        encoded_input = tokenizer(text, return_tensors='pt')
        output = model(**encoded_input)
        scores = output[0][0].detach().numpy()
        scores = softmax(scores)
        ranking = np.argsort(scores)
        ranking = ranking[::-1]
        print(text)
        for i in range(scores.shape[0]):
            l = config.id2label[ranking[i]]
            s = scores[ranking[i]]
            resultScore.append(f"{i + 1}) {l} {np.round(float(s), 4)}")
        return resultScore

    results = stringSentement(testTxt1)

    return render_template('index.html', variable=results)


if __name__ == "__main__":
    app.run(port='8088', threaded=False, debug=True)
